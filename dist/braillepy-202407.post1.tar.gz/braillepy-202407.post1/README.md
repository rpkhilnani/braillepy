# braillepy
This is a library to convert text to braille in python using unicode. This includes all the key characters on a Standard English Keyboard.
